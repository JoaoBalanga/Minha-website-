document.addEventListener("DOMContentLoaded", function() {
    console.log("Página carregada com sucesso!");
});